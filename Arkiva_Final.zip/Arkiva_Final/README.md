# Arkiva - GED Nouvelle Génération
Architecture complète prète pour la production et la conformité HDS.
