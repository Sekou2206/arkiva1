#!/bin/bash
# Script de déploiement pour Ubuntu Server LTS (Conformité HDS)
DOMAIN="arkiva.tondomaine.com"
GITHUB_REPO="https://github.com/TON-UTILISATEUR/arkiva.git"
DB_USER="arkiva_admin"
DB_PASS="UnMotDePasseTresComplex123!"
DB_NAME="arkiva_prod"

echo "[1/8] Mise à jour du système..."
apt update -y && apt upgrade -y
apt install -y git curl wget ufw nginx postgresql postgresql-contrib certbot python3-certbot-nginx python3 python3-pip python3-venv redis-server

echo "[2/8] Configuration du Pare-feu (UFW)..."
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow http
ufw allow https
ufw --force enable

echo "[3/8] Installation IDS/IPS Suricata..."
add-apt-repository ppa:oisf/suricata-stable -y
apt update -y
apt install -y suricata
systemctl enable suricata
systemctl start suricata

echo "[4/8] Configuration Base de données PostgreSQL..."
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
sudo -u postgres psql -d $DB_NAME -c "CREATE EXTENSION IF NOT EXISTS vector;"
systemctl restart postgresql

echo "[5/8] Clonage du code depuis GitHub..."
rm -rf /var/www/arkiva
git clone $GITHUB_REPO /var/www/arkiva

echo "[6/8] Déploiement Backend..."
cd /var/www/arkiva/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn

cat << 'EOL' > /etc/systemd/system/arkiva-backend.service
[Unit]
Description=Arkiva FastAPI Backend (Gunicorn)
After=network.target
[Service]
User=root
Group=root
WorkingDirectory=/var/www/arkiva/backend
ExecStart=/var/www/arkiva/backend/venv/bin/gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app -b 127.0.0.1:8000
Environment="DATABASE_URL=postgresql://arkiva_admin:UnMotDePasseTresComplex123!@localhost:5432/arkiva_prod"
Restart=always
[Install]
WantedBy=multi-user.target
EOL

systemctl daemon-reload
systemctl enable arkiva-backend
systemctl start arkiva-backend

echo "[7/8] Déploiement Frontend..."
cd /var/www/arkiva/frontend
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs
npm install
npm run build

cat << 'EOL' > /etc/systemd/system/arkiva-frontend.service
[Unit]
Description=Arkiva Next.js Frontend
After=network.target
[Service]
User=root
Group=root
WorkingDirectory=/var/www/arkiva/frontend
ExecStart=/usr/bin/npm start
Environment="NEXT_PUBLIC_API_URL=https://DOMAIN/api"
Restart=always
[Install]
WantedBy=multi-user.target
EOL

systemctl daemon-reload
systemctl enable arkiva-frontend
systemctl start arkiva-frontend

echo "[8/8] Configuration Nginx et TLS 1.3..."
cat << 'EOL' > /etc/nginx/sites-available/arkiva
server {
    listen 80;
    server_name DOMAIN;
    return 301 https://\$host\$request_uri;
}
server {
    listen 443 ssl http2;
    server_name DOMAIN;
    ssl_certificate /etc/letsencrypt/live/DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    location /api {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
EOL

sed -i "s/DOMAIN/$DOMAIN/g" /etc/nginx/sites-available/arkiva
ln -s /etc/nginx/sites-available/arkiva /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

echo "Déploiement terminé. Lancez: certbot --nginx -d $DOMAIN"
